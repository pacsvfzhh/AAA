import { createRoot } from 'react-dom/client';
import EmployeeDataMigration from '/root/app/code/src/components/admin/EmployeeDataMigration';
createRoot(document.getElementById('root')!).render(<div className="flex h-screen flex-col bg-slate-950"><EmployeeDataMigration /></div>);
