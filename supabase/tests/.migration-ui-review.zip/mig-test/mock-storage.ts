const w = window as any;
export async function createBrowserWorkspaceFactory() { return async () => ({}); }
export async function pickTransferDirectory() {
  w.__calls.pick++;
  if (w.__mock.pickFail) throw new DOMException('denied','AbortError');
  return { name: 'mock-export-dir', createFile(){throw new Error('no')}, async writeText(){} };
}
