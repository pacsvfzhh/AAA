const base = require('/root/app/code/tailwind.config.js');
module.exports = { ...base, content: ['/root/app/code/src/components/admin/EmployeeDataMigration.tsx'] };
