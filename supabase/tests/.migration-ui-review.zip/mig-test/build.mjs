import { build } from '/root/app/code/node_modules/esbuild/lib/main.js';
await build({ entryPoints:['/tmp/mig-test/entry.tsx'], bundle:true, outfile:'/tmp/mig-test/out.js', format:'iife', jsx:'automatic',
 nodePaths:['/root/app/code/node_modules'], define:{'process.env.NODE_ENV':'"production"'}, logLevel:'warning',
 plugins:[{name:'m',setup(b){
  b.onResolve({filter:/employeeTransfer\/siteTransfer$/},()=>({path:'/tmp/mig-test/mock-site.ts'}));
  b.onResolve({filter:/employeeTransfer\/browserStorage$/},()=>({path:'/tmp/mig-test/mock-storage.ts'}));
 }}]});
