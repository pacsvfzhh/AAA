const w = window as any;
w.__calls = { export: [], inspect: [], caps: 0, history: 0, pick: 0 };
export async function getSiteTransferCapabilities(signal?: AbortSignal) {
  w.__calls.caps++;
  if (w.__mock.capsError) throw new Error('RAW_CAPS_SECRET sqlstate 42883');
  return w.__mock.caps;
}
export async function getSiteTransferHistory(signal?: AbortSignal) {
  w.__calls.history++;
  if (w.__mock.historyError) throw new Error('RAW_HISTORY_SECRET relation private.x');
  return w.__mock.history;
}
const domains = ['shared','products','dispatch'];
export async function exportSiteBundleSet(o: any) {
  w.__calls.export.push({ admin: o.adminPassword, pass: o.passphrase, dir: o.directory.name });
  if (o.adminPassword === 'wrong-admin') throw new Error('RAW_AUTH_SECRET adminPassword=wrong-admin hunter2 stack at fn');
  for (let i = 0; i < domains.length; i++) {
    await o.beforeDomain(domains[i]);
    o.signal.throwIfAborted();
    o.onProgress({ domain: domains[i], phase: 'fetching', completedDomains: i, totalDomains: 3, rows: 100 * (i+1), files: i, bytes: 2048 * (i+1) });
    w.__calls.lastDomain = domains[i];
    await new Promise<void>((res, rej) => {
      w.__release = res;
      o.signal.addEventListener('abort', () => rej(new DOMException('x','AbortError')), { once: true });
    });
  }
  return { packageId: 'pkg-1', sourceSiteId: 'site-a', fullSiteComplete: false, importReady: false,
    volumes: domains.map((d,i)=>({ domain: d, filename: d+'.edx', cipherBytes: 4096*(i+1), cipherSha256: 'ab'.repeat(32), rows: 10, files: 0 })) };
}
export async function inspectSiteBundleSet(files: File[], pass: string, cw: any, o: any) {
  w.__calls.inspect.push({ names: files.map(f=>f.name), pass });
  if (pass === 'wrong-passphrase-123') throw new Error('RAW_DECRYPT_SECRET bad tag key=deadbeef');
  o.onProgress?.({ domain: 'shared', phase: 'decrypting', completedDomains: 1, totalDomains: 1, rows: 5, files: 0, bytes: 100 });
  return { packageId: 'pkg-i', sourceSiteId: 'site-b', fullSiteComplete: false, importReady: false,
    volumes: [{ domain: 'shared', filename: files[0].name, cipherBytes: files[0].size, cipherSha256: 'cd'.repeat(32), rows: 5, files: 0 }] };
}
